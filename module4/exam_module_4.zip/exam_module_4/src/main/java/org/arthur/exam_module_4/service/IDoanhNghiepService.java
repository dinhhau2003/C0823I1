package org.arthur.exam_module_4.service;

import org.arthur.exam_module_4.model.DoanhNghiep;

import java.util.List;

public interface IDoanhNghiepService {
    List<DoanhNghiep> getList();

}
