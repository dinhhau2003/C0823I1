package org.arthur.exam_module_4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamModule4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
