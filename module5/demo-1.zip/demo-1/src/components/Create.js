import React, { useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import { getCategories } from "../service/category-service";
import { createProduct } from "../service/product-service";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const Create = () => {
  const [categories, setCategories] = useState();
  const navigate = useNavigate();

  useEffect(() => {
    getCategories().then((data) => {
      setCategories(data);
    });
  }, []);

  return (
    <div>
      <Formik
        initialValues={{ name: "", price: "", category: "" }}
        onSubmit={(values) => {
          const prd = { ...values, category: JSON.parse(values.category) };
          createProduct(prd).then(() => {
            toast.success("Product created");
            navigate("/");
          });
        }}
      >
        {() => (
          <Form>
            <Field type="text" name="name" />
            <Field type="text" name="price" />
            <Field as="select" name="category">
              {categories &&
                categories.map((category) => (
                  <option key={category.id} value={JSON.stringify(category)}>
                    {category.name}
                  </option>
                ))}
            </Field>
            <button type="submit">Submit</button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default Create;
