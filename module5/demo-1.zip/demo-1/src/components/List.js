import React, { useEffect, useState } from "react";
import { getProducts } from "../service/product-service";
import ModalDelete from "./ModalDelete";
import { Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const List = () => {
  const [products, setProducts] = useState();
  const [show, setShow] = useState(false);
  const [product, setProduct] = useState();
  const [search, setSearch] = useState("");
  const navigate = useNavigate();

  const handleShow = (product) => {
    setProduct(product);
    setShow(true);
  };

  useEffect(() => {
    findAllProducts("");
  }, []);

  const findAllProducts = (name) => {
    getProducts(name).then((data) => {
      setProducts(data);
    });
  };

  const handleUpdateProduct = (id) => {
    navigate(`/update/${id}`);
  };

  const handleSearch = () => {
    findAllProducts(search);
  };

  const handleInputChange = (e) => {
    const { value } = e.target;
    setSearch(value);
  };

  if (!products) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <input type="text" placeholder="Search" onChange={handleInputChange} />
      <button onClick={handleSearch}>Search</button>
      <table className="table">
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>Delete</th>
            <th>Update</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td>{product.id}</td>
              <td>{product.name}</td>
              <td>{product.price}</td>
              <td>{product.category.name}</td>
              <td>
                <Button variant="danger" onClick={() => handleShow(product)}>
                  Delete
                </Button>
              </td>
              <td>
                <Button
                  variant="warning"
                  onClick={() => handleUpdateProduct(product.id)}
                >
                  Update
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {product && (
        <ModalDelete
          show={show}
          setShow={setShow}
          product={product}
          findAllProducts={findAllProducts}
        />
      )}
    </div>
  );
};

export default List;
