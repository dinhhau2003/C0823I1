import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { deleteProduct } from "../service/product-service";
import { toast } from "react-toastify";

function ModalDelete({ show, setShow, product, findAllProducts }) {
  const handleClose = () => setShow(false);

  const handleDeleteProduct = () => {
    deleteProduct(product.id).then(() => {
      handleClose();
      findAllProducts();
      toast.success(`Product ${product.name} deleted`);
    });
  };

  return (
    <>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>Bạn có muốn xóa sản phẩm có tên {product.name}?</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleDeleteProduct}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default ModalDelete;
