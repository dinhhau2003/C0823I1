import React, { useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import { getCategories } from "../service/category-service";
import { findProductById, updateProduct } from "../service/product-service";
import { toast } from "react-toastify";
import { useNavigate, useParams } from "react-router-dom";

const Update = () => {
  const { id } = useParams();
  const [product, setProduct] = useState();
  const [categories, setCategories] = useState();
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      findProductById(id).then((data) => {
        const prd = { ...data, category: JSON.stringify(data.category) };
        setProduct(prd);
      });
    }
  }, [id]);

  useEffect(() => {
    getCategories().then((data) => {
      setCategories(data);
    });
  }, []);

  if (!product) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <Formik
        initialValues={product}
        onSubmit={(values) => {
          const prd = { ...values, category: JSON.parse(values.category) };
          updateProduct(prd).then(() => {
            toast.success("Product updated");
            navigate("/");
          });
        }}
      >
        {() => (
          <Form>
            <Field type="text" name="name" />
            <Field type="text" name="price" />
            <Field as="select" name="category">
              {categories &&
                categories.map((category) => (
                  <option key={category.id} value={JSON.stringify(category)}>
                    {category.name}
                  </option>
                ))}
            </Field>
            <button type="submit">Submit</button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default Update;
