import axios from "axios";

export const getProducts = async (name) => {
  const res = await axios.get(
    `http://localhost:8080/products?name_like=${name}`
  );
  return res.data;
};

export const deleteProduct = async (id) => {
  await axios.delete(`http://localhost:8080/products/${id}`);
};

export const createProduct = async (product) => {
  await axios.post("http://localhost:8080/products", product);
};

export const findProductById = async (id) => {
  const res = await axios.get(`http://localhost:8080/products/${id}`);
  return res.data;
};

export const updateProduct = async (product) => {
  await axios.put(`http://localhost:8080/products/${product.id}`, product);
};
