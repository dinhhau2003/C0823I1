import React from 'react';
import Layout from './Layout';

const HomePage = () => {
  return (
    <Layout>
      
    </Layout>
  );
}

export default HomePage;
